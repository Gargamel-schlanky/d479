	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_89", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_89", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_276", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_276", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_6", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_277", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_277", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_7", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_279", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_279", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_9", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_9", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Panel_1", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Basic side", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_125", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_125", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_17", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_17", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_91", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_91", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_18", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_18", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_344", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_344", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Trash", "s-Path_344"]; 

	widgets.descriptionMap[["s-Cell_19", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_19", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_345", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_345", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Settings", "s-Path_345"]; 

	widgets.descriptionMap[["s-Cell_20", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_20", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_2", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Bookmark", "s-Path_2"]; 

	widgets.descriptionMap[["s-Cell_21", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_21", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rect_24", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_24", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rect_25", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_25", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rect_26", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_26", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_123", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_22", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_22", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_124", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_124", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_23", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_23", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_2", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Basic side", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_3", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Basic side", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_4", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_4", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Basic side", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_5", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_5", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Basic side", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_6", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_6", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Basic side", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Input_15", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_3", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["H2", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "c412f348-399c-4cad-a07e-63fbfd5950db"]] = ["H2", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_text_1", "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"]] = ["Search", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"]] = ["Search", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_text_1", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Search", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Search", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_2", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_6", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_2", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_7", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_3", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_8", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_5", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_10", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_10", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Panel_1", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Path_3", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_18", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_18", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_4", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_19", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_19", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_5", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Trash", "s-Path_5"]; 

	widgets.descriptionMap[["s-Cell_20", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_20", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_6", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Settings", "s-Path_6"]; 

	widgets.descriptionMap[["s-Cell_21", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_21", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_7", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Bookmark", "s-Path_7"]; 

	widgets.descriptionMap[["s-Cell_22", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_22", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_8", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_9", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_10", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_11", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_23", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_23", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_12", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_24", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_24", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Panel_2", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_3", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_4", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_4", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_5", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_5", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_6", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_6", "7d210b43-d1e9-431f-9d92-a10f222f4846"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Input_text_1", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Search", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Search", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_2", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_6", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_2", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_7", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_3", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_8", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_5", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_10", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_10", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Panel_1", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Path_3", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_18", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_18", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_4", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_19", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_19", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_5", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Trash", "s-Path_5"]; 

	widgets.descriptionMap[["s-Cell_20", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_20", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_6", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Settings", "s-Path_6"]; 

	widgets.descriptionMap[["s-Cell_21", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_21", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_7", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Bookmark", "s-Path_7"]; 

	widgets.descriptionMap[["s-Cell_22", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_22", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_8", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_9", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_10", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_11", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_23", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_23", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_12", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_24", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_24", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Panel_2", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_3", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_4", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_4", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_5", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_5", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_6", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_6", "15fbfcae-beee-4b65-84bf-a602881a96cc"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Input_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Text_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Cell_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_1"]; 

	widgets.descriptionMap[["s-Panel_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Trash", "s-Path_5"]; 

	widgets.descriptionMap[["s-Cell_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Settings", "s-Path_6"]; 

	widgets.descriptionMap[["s-Cell_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Bookmark", "s-Path_7"]; 

	widgets.descriptionMap[["s-Cell_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Path_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Cell_24", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_24", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Content_grid_2"]; 

	widgets.descriptionMap[["s-Panel_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Panel_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic side", "s-Dynamic_panel_1"]; 

	widgets.descriptionMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic", "s-Button_3"]; 

	