(function(window, undefined) {

  var jimLinks = {
    "c412f348-399c-4cad-a07e-63fbfd5950db" : {
      "Cell_6" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Paragraph_276" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Cell_7" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Paragraph_277" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Cell_9" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Paragraph_279" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"
      ],
      "Button_3" : [
        "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"
      ],
      "Button_4" : [
        "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"
      ],
      "Button_5" : [
        "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001"
      ]
    },
    "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "7d210b43-d1e9-431f-9d92-a10f222f4846" : {
      "Cell_7" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Cell_8" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Text_3" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Cell_10" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Text_5" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "15fbfcae-beee-4b65-84bf-a602881a96cc" : {
      "Cell_7" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Text_2" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Cell_8" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Text_3" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Cell_10" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_6" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Button_1" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Cell_7" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Text_3" : [
        "7d210b43-d1e9-431f-9d92-a10f222f4846"
      ],
      "Cell_8" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Text_4" : [
        "c412f348-399c-4cad-a07e-63fbfd5950db"
      ],
      "Cell_10" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Text_6" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ],
      "Button_3" : [
        "15fbfcae-beee-4b65-84bf-a602881a96cc"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);