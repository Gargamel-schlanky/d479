(function(window, undefined) {
  var dictionary = {
    "c412f348-399c-4cad-a07e-63fbfd5950db": "Where to stay/ how to get around",
    "5d1fdc1e-5858-4e4f-bb4d-6751f77d3001": "External link",
    "7d210b43-d1e9-431f-9d92-a10f222f4846": "What to do",
    "15fbfcae-beee-4b65-84bf-a602881a96cc": "Faq's",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Landing (Home)",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);