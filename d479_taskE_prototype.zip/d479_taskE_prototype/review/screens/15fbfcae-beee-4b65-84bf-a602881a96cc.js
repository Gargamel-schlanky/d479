var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1741745006135.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-15fbfcae-beee-4b65-84bf-a602881a96cc" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Faq&#039;s"width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/15fbfcae-beee-4b65-84bf-a602881a96cc/style-1741745006135.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/15fbfcae-beee-4b65-84bf-a602881a96cc/fonts-1741745006135.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1024.00px" datasizeheight="1024.08px" dataX="0.00" dataY="0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/006faf6f-2c3b-4ffb-8d2b-7a044cd5da74.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="257.00px" datasizeheight="74.00px" dataX="42.00" dataY="30.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/36c10a5d-814e-4245-a8fe-44d46248ad23.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="853.00px" datasizeheight="904.00px" datasizewidthpx="852.9999999999999" datasizeheightpx="903.9999999999999" dataX="85.50" dataY="67.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="224.00px" datasizeheight="74.00px" dataX="45.00" dataY="0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3b2adf20-6ecf-48ea-bcc2-55441e1c6f43.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Search input" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="638.50" dataY="14.58" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="search icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="650.50" dataY="29.58"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.000000000000002" viewBox="650.4999999999993 29.57766950379181 13.0 13.000000000000002" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-15fbf" d="M659.3530000887412 34.89466944115046 C659.3530000887412 36.84466970215607 657.7670001983636 38.430668940019714 655.816999937358 38.430668940019714 C653.8670000026094 38.430668940019714 652.2680000756909 36.84466970215607 652.2680000756909 34.89466944115046 C652.2680000756909 32.931669796118086 653.8539999660686 31.345669253226433 655.816999937358 31.345669253226433 C657.7670001983636 31.345669253226433 659.3530000887412 32.944669180144864 659.3530000887412 34.89466944115046 L659.3530000887412 34.89466944115046 Z M660.1979998538362 37.89766939938957 C660.809000266225 37.02666890869904 661.1339998747167 35.96066982743876 661.1339998747167 34.89466944115046 C661.1339998747167 31.956669665615284 658.7549997128932 29.57766950379181 655.816999937358 29.57766950379181 C652.8789999986943 29.57766950379181 650.4999999999993 31.956669665615284 650.4999999999993 34.89466944115046 C650.4999999999993 37.832669869199655 652.8789999986943 40.21166937850912 655.816999937358 40.21166937850912 C656.8830003236462 40.21166937850912 657.9490000574206 39.873669733476746 658.8329999321379 39.27566935762867 L662.134999425787 42.57766950379181 L663.4999999999993 41.212668929579486 L660.1979998538362 37.89766939938957 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-15fbf" fill="#A1A1A1" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="269.00" dataY="413.57" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_panel_1" class="dynamicpanel firer commentable non-processed" customid="Basic slide menu" datasizewidth="176.00px" datasizeheight="169.00px" dataX="6.00" dataY="152.00" >\
        <div id="s-Panel_1" class="panel default firer commentable non-processed" customid="Expanded"  datasizewidth="176.00px" datasizeheight="169.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Content_grid_1" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="179.00px" datasizeheight="224.00px" dataX="1.00" dataY="-53.00" originalwidth="179.00000000000057px" originalheight="223.99999999999994px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_6" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="179.00000000000057px" originalheight="56.00000000000002px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_6 Content_grid_1" valign="middle" align="right" hSpacing="15" vSpacing="0"><div id="s-Path_2" class="path firer click mouseenter mouseleave commentable non-processed" customid="arrow"   datasizewidth="14.00px" datasizeheight="14.00px" dataX="0.00" dataY="0.00"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="14.0" viewBox="0.0 0.0 14.0 14.0" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_2-15fbf" d="M7.0 0.0 L5.766250029206276 1.233749970793724 L10.648750066757202 6.125 L0.0 6.125 L0.0 7.875 L10.648750066757202 7.875 L5.766250133514404 12.766250133514404 L7.0 14.0 L14.0 7.0 L7.0 0.0 Z "></path>\
                                          	    </defs>\
                                          	    <g transform="rotate(180.0 7.0 7.0)" style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-15fbf" fill="#ABABAB" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_7" customid="Cell 2" class="cellcontainer firer mouseenter mouseleave click non-processed"    datasizewidth="181.00px" datasizeheight="58.00px" dataX="0.00" dataY="0.00" originalwidth="179.00000000000057px" originalheight="55.999999999999986px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="left ghostHLayout">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout horizontal insertionpoint verticalalign Cell_7 Content_grid_1" valign="middle" align="left" hSpacing="21" vSpacing="0"><div id="s-Text_2" class="richtext manualfit firer click ie-background commentable non-processed" customid="What to do on the Island"   datasizewidth="124.09px" datasizeheight="54.00px" dataX="0.00" dataY="1.00" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Text_2_0">What to do on the Island</span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_8" customid="Cell 3" class="cellcontainer firer mouseenter mouseleave click non-processed"    datasizewidth="179.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="179.00000000000057px" originalheight="55.999999999999986px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="left ghostHLayout">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout horizontal insertionpoint verticalalign Cell_8 Content_grid_1" valign="middle" align="left" hSpacing="21" vSpacing="0"><div id="s-Text_3" class="richtext manualfit firer click ie-background commentable non-processed" customid="Lodging &amp; Transportation"   datasizewidth="120.52px" datasizeheight="54.00px" dataX="0.00" dataY="1.00" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Text_3_0">Lodging &amp; <br />Transportation</span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_10" customid="Cell 5" class="cellcontainer firer mouseenter mouseleave click non-processed"    datasizewidth="181.00px" datasizeheight="58.00px" dataX="0.00" dataY="0.00" originalwidth="179.00000000000057px" originalheight="55.99999999999994px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="left ghostHLayout">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout horizontal insertionpoint verticalalign Cell_10 Content_grid_1" valign="middle" align="left" hSpacing="21" vSpacing="0"><div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="FAQ&#039;s"   datasizewidth="127.37px" datasizeheight="27.00px" dataX="0.00" dataY="14.50" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Text_5_0">FAQ&#039;s</span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_2" class="panel hidden firer commentable non-processed" customid="Collapsed"  datasizewidth="75.00px" datasizeheight="1000.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Content_grid_2" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="75.00px" datasizeheight="392.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="392.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_18" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="56.00000000000003px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_18 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Path_3" class="path firer click mouseenter mouseleave commentable non-processed" customid="arrow"   datasizewidth="14.00px" datasizeheight="14.00px" dataX="0.00" dataY="0.00"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="14.0" viewBox="0.0 0.0 14.0 14.0" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_3-15fbf" d="M7.0 0.0 L5.766250029206276 1.233749970793724 L10.648750066757202 6.125 L0.0 6.125 L0.0 7.875 L10.648750066757202 7.875 L5.766250133514404 12.766250133514404 L7.0 14.0 L14.0 7.0 L7.0 0.0 Z "></path>\
                                          	    </defs>\
                                          	    <g style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-15fbf" fill="#ABABAB" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_19" customid="Cell 2" class="cellcontainer firer mouseenter mouseleave ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="55.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_19 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Path_4" class="path firer commentable non-processed" customid="attach-icon"   datasizewidth="11.00px" datasizeheight="18.00px" dataX="30.00" dataY="30.00"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="11.0" height="18.000000000003638" viewBox="30.0 30.0 11.0 18.000000000003638" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_4-15fbf" d="M39.5 33.599999999998545 L39.5 43.05000000000291 C39.5 45.038964843746726 37.709960937500114 46.649999999999636 35.5 46.649999999999636 C33.289978027343864 46.649999999999636 31.499999999999886 45.038964843746726 31.499999999999886 43.05000000000291 L31.499999999999886 33.599999999998545 C31.499999999999886 32.358105468745634 32.6199951171875 31.349999999998545 34.000000000000114 31.349999999998545 C35.380004882812614 31.349999999998545 36.50000000000023 32.358105468745634 36.50000000000023 33.599999999998545 L36.50000000000023 42.150000000001455 C36.50000000000023 42.64482421874527 36.049987792968636 43.05000000000291 35.5 43.05000000000291 C34.950012207031364 43.05000000000291 34.499999999999886 42.64482421874527 34.499999999999886 42.150000000001455 L34.499999999999886 33.599999999998545 L33.0 33.599999999998545 L33.0 42.150000000001455 C33.0 43.39189453125073 34.119995117187386 44.400000000003274 35.5 44.400000000003274 C36.88000488281273 44.400000000003274 38.000000000000114 43.39189453125073 38.000000000000114 42.150000000001455 L38.000000000000114 33.599999999998545 C38.000000000000114 31.611035156249272 36.20996093750023 30.0 34.000000000000114 30.0 C31.789978027343864 30.0 30.0 31.611035156249272 30.0 33.599999999998545 L30.0 43.05000000000291 C30.0 45.786035156254 32.4599609375 48.00000000000364 35.5 48.00000000000364 C38.53997802734409 48.00000000000364 41.0 45.786035156254 41.0 43.05000000000291 L41.0 33.599999999998545 L39.5 33.599999999998545 Z "></path>\
                                          	    </defs>\
                                          	    <g style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-15fbf" fill="#313033" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_20" customid="Cell 3" class="cellcontainer firer mouseenter mouseleave ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="55.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_20 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Path_5" class="path firer commentable non-processed" customid="trash-icon"   datasizewidth="14.00px" datasizeheight="18.00px" dataX="30.00" dataY="0.00"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="18.0" viewBox="30.0 0.0 14.0 18.0" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_5-15fbf" d="M41.0 6.0 L41.0 16.0 L33.0 16.0 L33.0 6.0 L41.0 6.0 M39.5 0.0 L34.5 0.0 L33.5 1.0 L30.0 1.0 L30.0 3.0 L44.0 3.0 L44.0 1.0 L40.5 1.0 L39.5 0.0 Z M43.0 4.0 L31.0 4.0 L31.0 16.0 C31.0 17.100000023841858 31.899999976158142 18.0 33.0 18.0 L41.0 18.0 C42.10000002384186 18.0 43.0 17.100000023841858 43.0 16.0 L43.0 4.0 Z "></path>\
                                          	    </defs>\
                                          	    <g style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-15fbf" fill="#313033" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_21" customid="Cell 4" class="cellcontainer firer mouseenter mouseleave ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="55.99999999999996px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_21 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Path_6" class="path firer commentable non-processed" customid="settings-icon"   datasizewidth="18.45px" datasizeheight="18.97px" dataX="30.00" dataY="0.00"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="18.449999999999996" height="18.967581909688953" viewBox="30.0 0.0 18.449999999999996 18.967581909688953" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_6-15fbf" d="M46.27355155764397 10.413201908211088 C46.31148672015614 10.109720608113708 46.339938093806765 9.806239308016327 46.339938093806765 9.483790387799997 C46.339938093806765 9.16134149584757 46.311486721922634 8.85786016748629 46.27355155764397 8.554378867388909 L48.27463132539977 6.989553401396334 C48.45482334909908 6.8472965331432185 48.5022423004728 6.5912341985515095 48.388436812936284 6.382590801201573 L46.49167864493181 3.1011991343760386 C46.40632452397993 2.949458484327348 46.24510009213567 2.8641043633754784 46.07439185023193 2.8641043633754784 C46.01748910646368 2.8641043633754784 45.960586362695416 2.873588154003521 45.91316740425572 2.8925557352596076 L43.5517034760457 3.8409348192618467 C43.05854637045343 3.461583180008171 42.52745402462327 3.1486180698513166 41.948942769815226 2.9115232988507564 L41.5885587224166 0.39831863580034677 C41.5601072569083 0.17070829843153712 41.36094761309005 0.0 41.123852842089484 0.0 L37.33033650608053 0.0 C37.09324173507997 0.0 36.894082119525606 0.17070824190373868 36.86563074587498 0.3983192028448248 L36.505246698476356 2.9115238658952354 C35.92673544366832 3.148618636895794 35.39564321089375 3.471067500584324 34.902485992245886 3.840935386306324 L32.541022064035865 2.892556302304085 C32.48411932026761 2.873588721048 32.42721657649935 2.8641049304199555 32.370313822132125 2.8641049304199555 C32.209089376155916 2.8641049304199555 32.0478649301797 2.949459051371825 31.96251080922783 3.1011997014205157 L30.06575264122335 6.382591368246052 C29.942463364825286 6.591234765595988 29.999366105060556 6.847297128451595 30.17955812875987 6.989553968440813 L32.18063789651567 8.554379434433386 C32.14270273400349 8.857860734530767 32.114251360352874 9.170825816423722 32.114251360352874 9.483790954844476 C32.114251360352874 9.79675606500133 32.142702732237005 10.109721175158185 32.18063789651567 10.413202475255567 L30.17955812875987 11.978027941248138 C29.999366105060556 12.120284809501257 29.951947153686834 12.376347144092966 30.06575264122335 12.584990541442902 L31.96251080922783 15.86638220826844 C32.0478649301797 16.01812285831713 32.20908936202397 16.103476979269 32.379797603927706 16.103476979269 C32.43670034769596 16.103476979269 32.49360309146422 16.093993188640955 32.541022049903916 16.075025607384866 L34.90248597811394 15.126646523382632 C35.395643083706204 15.505998162636306 35.92673542953637 15.818963272793159 36.505246684344414 16.05605804379372 L36.86563073174304 18.56926270684413 C36.89408210362716 18.796873681917166 37.09324170681607 18.967581909688953 37.33033649194858 18.967581909688953 L41.123852827957535 18.967581909688953 C41.36094759895809 18.967581909688953 41.560107214512456 18.796873667785217 41.58855858816308 18.56926270684413 L41.94894263556171 16.05605804379372 C42.52745389036974 15.818963272793159 43.05854612314431 15.49651440910463 43.55170334179218 15.126646523382632 L45.9131672700022 16.075025607384866 C45.97007001377045 16.093993188640955 46.026972757538715 16.103476979269 46.08387551190593 16.103476979269 C46.245099957882154 16.103476979269 46.40632440385836 16.01812285831713 46.49167852481023 15.86638220826844 L48.38843669281471 12.584990541442902 C48.50224218035123 12.376347144092966 48.45482322897751 12.120284781237356 48.2746312052782 11.978027941248138 L46.2735514375224 10.413202475255567 Z M44.395760953230635 8.79147363838947 C44.43369611574281 9.085471156691275 44.44317990813735 9.284630743981737 44.44317990813735 9.483790387799997 C44.44317990813735 9.682949989222411 44.42421232688126 9.891593400704295 44.395760953230635 10.176107137210527 L44.262987880905044 11.247775497610835 L45.10704525210036 11.911640845106842 L46.131294703522805 12.70827925079649 L45.4674293560268 13.855817978616988 L44.26298793743285 13.372144654820296 L43.27667372624831 12.97382545197547 L42.42313257325742 13.61872323588033 C42.015329560353116 13.922204535977711 41.62649416756777 14.1498155251827 41.237658718254615 14.311039985290861 L40.23237694347893 14.71884299819516 L40.08063629343024 15.790511358595463 L39.8909604738034 17.07082314460961 L38.56322977881139 17.07082314460961 L38.38303775511208 15.790511358595463 L38.23129710506338 14.71884299819516 L37.226015330287694 14.311039985290861 C36.8182123173834 14.140331743387122 36.438860706393626 13.922204564241609 36.05950903887605 13.637690855999278 L35.19648404756178 12.97382550850327 L34.19120227278609 13.381628521407567 L32.98676085419214 13.865301845204263 L32.32289550669614 12.717763117383761 L33.34714495811857 11.921124711694114 L34.191202329313896 11.257259364198106 L34.0584292569883 10.1855910037978 C34.029977885104174 9.891593485495994 34.01101030208159 9.673466278086584 34.01101030208159 9.483790472591696 C34.01101030208159 9.294114667096807 34.02997788333768 9.075987459687397 34.0584292569883 8.791473723181166 L34.191202329313896 7.7198053627808605 L33.34714495811857 7.055940015284852 L32.32289550669614 6.259301609595203 L32.98676085419214 5.111762881774704 L34.19120227278609 5.5954362055713975 L35.17751648397063 5.993755408416222 L36.03105763696153 5.348857624511366 C36.43886064986582 5.045376324413985 36.827696042651176 4.8177653352090015 37.216531491964325 4.656540875100836 L38.221813266740014 4.248737862196538 L38.3735539167887 3.1770695017962325 L38.563229736415536 1.8967577157820892 L39.88147664961198 1.8967577157820892 L40.061668673311296 3.1770695017962325 L40.21340932335998 4.248737862196538 L41.21869109813567 4.656540875100836 C41.62649411103997 4.827249117004573 42.00584572202975 5.045376296150085 42.385197389547315 5.329890004392418 L43.24822238086159 5.993755351888424 L44.25350415563727 5.585952338984125 L45.45794557423122 5.102279015187431 L46.12181092172723 6.249817743007931 L45.10704525210036 7.055939987020954 L44.262987880905044 7.719805334516963 L44.395760953230635 8.791473694917267 Z M39.22709467408501 5.690274504013432 C37.131176862262265 5.690274504013432 35.43357833807605 7.387873028199648 35.43357833807605 9.483790840022385 C35.43357833807605 11.579708651845124 37.131176862262265 13.27730717603134 39.22709467408501 13.27730717603134 C41.323012485907746 13.27730717603134 43.020611010093965 11.579708651845124 43.020611010093965 9.483790840022385 C43.020611010093965 7.387873028199648 41.323012485907746 5.690274504013432 39.22709467408501 5.690274504013432 Z M39.22709467408501 11.380549008026863 C38.18387765907143 11.380549008026863 37.33033650608053 10.527007855035967 37.33033650608053 9.483790840022385 C37.33033650608053 8.440573825008803 38.18387765907143 7.587032672017909 39.22709467408501 7.587032672017909 C40.27031168909859 7.587032672017909 41.123852842089484 8.440573825008803 41.123852842089484 9.483790840022385 C41.123852842089484 10.527007855035967 40.27031168909859 11.380549008026863 39.22709467408501 11.380549008026863 Z "></path>\
                                          	    </defs>\
                                          	    <g style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-15fbf" fill="#313033" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_22" customid="Cell 5" class="cellcontainer firer mouseenter mouseleave ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="55.99999999999996px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_22 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Path_7" class="path firer commentable non-processed" customid="bookmark-icon"   datasizewidth="13.00px" datasizeheight="16.71px" dataX="34.50" dataY="18.61"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="16.71428571428571" viewBox="34.503793239593506 18.60896587371826 13.0 16.71428571428571" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_7-15fbf" d="M45.646650382450645 18.60896587371826 L36.36093609673636 18.60896587371826 C35.339507503168925 18.60896587371826 34.51307894502367 19.44468013729368 34.51307894502367 20.46610873086112 L34.503793239593506 35.32325158800397 L41.003793239593506 32.53753730228969 L47.503793239593506 35.32325158800397 L47.503793239593506 20.46610873086112 C47.503793239593506 19.44468013729368 46.66807897601809 18.60896587371826 45.646650382450645 18.60896587371826 Z M45.646650382450645 32.53753730228969 L41.003793239593506 30.513251526015143 L36.36093609673636 32.53753730228969 L36.36093609673636 20.46610873086112 L45.646650382450645 20.46610873086112 L45.646650382450645 32.53753730228969 Z "></path>\
                                          	    </defs>\
                                          	    <g style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-15fbf" fill="#313033" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_23" customid="Cell 6" class="cellcontainer firer mouseenter mouseleave ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="55.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_23 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div class="relativeLayoutWrapper s-Group_2 "><div class="relativeLayoutWrapperResponsive">\
                                      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="graphics icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
                                        <div id="s-Path_8" class="path firer commentable non-processed" customid="Rect 3"   datasizewidth="2.00px" datasizeheight="10.00px" dataX="367.00" dataY="287.00"  >\
                                          <div class="borderLayer">\
                                          	<div class="imageViewport">\
                                            	<?xml version="1.0" encoding="UTF-8"?>\
                                            	<svg xmlns="http://www.w3.org/2000/svg" width="2.0" height="10.0" viewBox="367.0 287.0 2.0 10.0" preserveAspectRatio="none">\
                                            	  <g>\
                                            	    <defs>\
                                            	      <path id="s-Path_8-15fbf" d="M367.0 287.0 L369.0 287.0 L369.0 297.0 L367.0 297.0 Z "></path>\
                                            	    </defs>\
                                            	    <g style="mix-blend-mode:normal">\
                                            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-15fbf" fill="#000000" fill-opacity="1.0"></use>\
                                            	    </g>\
                                            	  </g>\
                                            	</svg>\
\
                                            </div>\
                                          </div>\
                                        </div>\
                                        <div id="s-Path_9" class="path firer commentable non-processed" customid="Rect 4"   datasizewidth="2.00px" datasizeheight="5.00px" dataX="371.00" dataY="287.00"  >\
                                          <div class="borderLayer">\
                                          	<div class="imageViewport">\
                                            	<?xml version="1.0" encoding="UTF-8"?>\
                                            	<svg xmlns="http://www.w3.org/2000/svg" width="2.0" height="5.0" viewBox="371.0 287.0 2.0 5.0" preserveAspectRatio="none">\
                                            	  <g>\
                                            	    <defs>\
                                            	      <path id="s-Path_9-15fbf" d="M371.0 287.0 L373.0 287.0 L373.0 292.0 L371.0 292.0 Z "></path>\
                                            	    </defs>\
                                            	    <g style="mix-blend-mode:normal">\
                                            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-15fbf" fill="#000000" fill-opacity="1.0"></use>\
                                            	    </g>\
                                            	  </g>\
                                            	</svg>\
\
                                            </div>\
                                          </div>\
                                        </div>\
                                        <div id="s-Path_10" class="path firer commentable non-processed" customid="Rect 5"   datasizewidth="2.00px" datasizeheight="8.00px" dataX="375.00" dataY="287.00"  >\
                                          <div class="borderLayer">\
                                          	<div class="imageViewport">\
                                            	<?xml version="1.0" encoding="UTF-8"?>\
                                            	<svg xmlns="http://www.w3.org/2000/svg" width="2.0" height="8.0" viewBox="375.0 287.0 2.0 8.0" preserveAspectRatio="none">\
                                            	  <g>\
                                            	    <defs>\
                                            	      <path id="s-Path_10-15fbf" d="M375.0 287.0 L377.0 287.0 L377.0 295.0 L375.0 295.0 Z "></path>\
                                            	    </defs>\
                                            	    <g style="mix-blend-mode:normal">\
                                            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-15fbf" fill="#000000" fill-opacity="1.0"></use>\
                                            	    </g>\
                                            	  </g>\
                                            	</svg>\
\
                                            </div>\
                                          </div>\
                                        </div>\
                                        <div id="s-Path_11" class="path firer commentable non-processed" customid="Path 11"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="363.00" dataY="283.00"  >\
                                          <div class="borderLayer">\
                                          	<div class="imageViewport">\
                                            	<?xml version="1.0" encoding="UTF-8"?>\
                                            	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="18.0" viewBox="363.0 283.0 18.0 18.0" preserveAspectRatio="none">\
                                            	  <g>\
                                            	    <defs>\
                                            	      <path id="s-Path_11-15fbf" d="M379.0 283.0 L365.0 283.0 C363.90000009536743 283.0 363.0 283.90000009536743 363.0 285.0 L363.0 299.0 C363.0 300.10000002384186 363.89999997615814 301.0 365.0 301.0 L379.0 301.0 C380.10000002384186 301.0 381.0 300.10000002384186 381.0 299.0 L381.0 285.0 C381.0 283.90000009536743 380.1000003814697 283.0 379.0 283.0 Z M379.0 299.0 L365.0 299.0 L365.0 285.0 L379.0 285.0 L379.0 299.0 Z "></path>\
                                            	    </defs>\
                                            	    <g style="mix-blend-mode:normal">\
                                            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-15fbf" fill="#000000" fill-opacity="1.0"></use>\
                                            	    </g>\
                                            	  </g>\
                                            	</svg>\
\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      </div></div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_24" customid="Cell 7" class="cellcontainer firer mouseenter mouseleave ie-background non-processed"    datasizewidth="75.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="75.0px" originalheight="55.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_24 Content_grid_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Path_12" class="path firer commentable non-processed" customid="shop icon"   datasizewidth="16.00px" datasizeheight="20.00px" dataX="0.00" dataY="0.00"  >\
                                        <div class="borderLayer">\
                                        	<div class="imageViewport">\
                                          	<?xml version="1.0" encoding="UTF-8"?>\
                                          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="20.0" viewBox="0.0 0.0 16.0 20.0" preserveAspectRatio="none">\
                                          	  <g>\
                                          	    <defs>\
                                          	      <path id="s-Path_12-15fbf" d="M14.0 4.0 L12.0 4.0 C12.0 1.7899999618530273 10.210000038146973 0.0 8.0 0.0 C5.789999961853027 0.0 4.0 1.7899999618530273 4.0 4.0 L2.0 4.0 C0.9000000953674316 4.0 0.0 4.900000095367432 0.0 6.0 L0.0 18.0 C0.0 19.100000023841858 0.8999999761581421 20.0 2.0 20.0 L14.0 20.0 C15.100000023841858 20.0 16.0 19.100000023841858 16.0 18.0 L16.0 6.0 C16.0 4.900000095367432 15.100000381469727 4.0 14.0 4.0 Z M8.0 2.0 C9.100000023841858 2.0 10.0 2.899999976158142 10.0 4.0 L6.0 4.0 C6.0 2.9000000953674316 6.899999618530273 2.0 8.0 2.0 Z M14.0 18.0 L2.0 18.0 L2.0 6.0 L4.0 6.0 L4.0 8.0 C4.0 8.550000011920929 4.449999988079071 9.0 5.0 9.0 C5.550000011920929 9.0 6.0 8.550000011920929 6.0 8.0 L6.0 6.0 L10.0 6.0 L10.0 8.0 C10.0 8.550000011920929 10.449999988079071 9.0 11.0 9.0 C11.550000011920929 9.0 12.0 8.550000011920929 12.0 8.0 L12.0 6.0 L14.0 6.0 L14.0 18.0 Z "></path>\
                                          	    </defs>\
                                          	    <g style="mix-blend-mode:normal">\
                                          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-15fbf" fill="#000000" fill-opacity="1.0"></use>\
                                          	    </g>\
                                          	  </g>\
                                          	</svg>\
\
                                          </div>\
                                        </div>\
                                      </div></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_3" class="panel hidden firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="179.00px" datasizeheight="412.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_4" class="panel hidden firer ie-background commentable non-processed" customid="Panel 4"  datasizewidth="179.00px" datasizeheight="412.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_5" class="panel hidden firer ie-background commentable non-processed" customid="Panel 5"  datasizewidth="179.00px" datasizeheight="412.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_6" class="panel hidden firer ie-background commentable non-processed" customid="Panel 6"  datasizewidth="179.00px" datasizeheight="412.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Home"   datasizewidth="176.00px" datasizeheight="46.00px" dataX="6.00" dataY="107.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Home</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="200.00px" datasizeheight="200.00px" dataX="208.00" dataY="102.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/113bc25d-ca08-4cb8-8771-7a1e5ba693a0.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="501.00px" datasizeheight="498.00px" datasizewidthpx="501.0000000000002" datasizeheightpx="498.0" dataX="426.00" dataY="102.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="What power outlets are us"   datasizewidth="476.36px" datasizeheight="477.00px" dataX="445.82" dataY="107.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">What power outlets are used on the island?<br /></span><span id="rtr-s-Text_6_1">Power outlets are 120 volts (the same as in the United States). <br /><br /></span><span id="rtr-s-Text_6_2">When is alcohol not available to be served?<br /></span><span id="rtr-s-Text_6_3">Alcohol is not allowed to be served or sold between the hours of midnight and 9:00 a.m. <br /><br /></span><span id="rtr-s-Text_6_4">What is the legal drinking age in Taniti?<br /></span><span id="rtr-s-Text_6_5">The drinking age on Taniti is 18 and the drinking age is not strictly enforced.<br /><br /></span><span id="rtr-s-Text_6_6">Are there many english speakers on the island?<br /></span><span id="rtr-s-Text_6_7">Many younger Tanitians speak fluent English. Very little English is spoken in rural areas, especially by the older residents.<br /><br /></span><span id="rtr-s-Text_6_8">What medical facilities are available on the island?<br /></span><span id="rtr-s-Text_6_9">There is one hospital and several clinics. The hospital has many multilingual employees.<br /><br /></span><span id="rtr-s-Text_6_10">Is crime an issue in Taniti?<br /></span><span id="rtr-s-Text_6_11">Violent crime is very rare on Taniti, but as tourism increases, there are more reports of pickpocketing and other petty crimes.<br /><br /></span><span id="rtr-s-Text_6_12">What holidays are celebrated in Taniti?<br /></span><span id="rtr-s-Text_6_13">Taniti enjoys a large number of national holidays, and many tourist attractions and restaurants will be closed on holidays, so visitors should plan accordingly.<br /><br /></span><span id="rtr-s-Text_6_14">What currency is accepted on the island?<br /></span><span id="rtr-s-Text_6_15">Taniti uses the U.S. dollar as its currency, but many businesses will also accept euros and yen. Several banks facilitate currency exchange, and many businesses accept major credit cards.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="Ingo, J. (2016)"   datasizewidth="51.59px" datasizeheight="9.00px" dataX="906.00" dataY="1004.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Ingo, J. (2016)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext autofit firer ie-background commentable non-processed" customid="Socha, A (2018)"   datasizewidth="57.81px" datasizeheight="9.00px" dataX="219.00" dataY="287.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Socha, A (2018)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;