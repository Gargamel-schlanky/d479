var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1741745006135.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-5d1fdc1e-5858-4e4f-bb4d-6751f77d3001" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="External link"width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/5d1fdc1e-5858-4e4f-bb4d-6751f77d3001/style-1741745006135.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1024.00px" datasizeheight="1024.08px" dataX="-0.00" dataY="-0.04"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/006faf6f-2c3b-4ffb-8d2b-7a044cd5da74.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="257.00px" datasizeheight="74.00px" dataX="42.00" dataY="30.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/36c10a5d-814e-4245-a8fe-44d46248ad23.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="853.00px" datasizeheight="925.00px" datasizewidthpx="852.9999999999999" datasizeheightpx="925.0" dataX="85.50" dataY="67.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="224.00px" datasizeheight="74.00px" dataX="45.00" dataY="0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3b2adf20-6ecf-48ea-bcc2-55441e1c6f43.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Search input" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="638.50" dataY="14.58" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="search icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="650.50" dataY="29.58"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.000000000000002" viewBox="650.4999999999993 29.57766950379181 13.0 13.000000000000002" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-5d1fd" d="M659.3530000887412 34.89466944115046 C659.3530000887412 36.84466970215607 657.7670001983636 38.430668940019714 655.816999937358 38.430668940019714 C653.8670000026094 38.430668940019714 652.2680000756909 36.84466970215607 652.2680000756909 34.89466944115046 C652.2680000756909 32.931669796118086 653.8539999660686 31.345669253226433 655.816999937358 31.345669253226433 C657.7670001983636 31.345669253226433 659.3530000887412 32.944669180144864 659.3530000887412 34.89466944115046 L659.3530000887412 34.89466944115046 Z M660.1979998538362 37.89766939938957 C660.809000266225 37.02666890869904 661.1339998747167 35.96066982743876 661.1339998747167 34.89466944115046 C661.1339998747167 31.956669665615284 658.7549997128932 29.57766950379181 655.816999937358 29.57766950379181 C652.8789999986943 29.57766950379181 650.4999999999993 31.956669665615284 650.4999999999993 34.89466944115046 C650.4999999999993 37.832669869199655 652.8789999986943 40.21166937850912 655.816999937358 40.21166937850912 C656.8830003236462 40.21166937850912 657.9490000574206 39.873669733476746 658.8329999321379 39.27566935762867 L662.134999425787 42.57766950379181 L663.4999999999993 41.212668929579486 L660.1979998538362 37.89766939938957 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-5d1fd" fill="#A1A1A1" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="269.00" dataY="413.57" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="You are being directed to"   datasizewidth="306.89px" datasizeheight="18.00px" dataX="358.55" dataY="209.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">You are being directed to another webpage</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="return home"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="437.00" dataY="268.24" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">return home</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Ingo, J. (2016)"   datasizewidth="51.59px" datasizeheight="9.00px" dataX="923.00" dataY="1002.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Ingo, J. (2016)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;